import threading
import socket
import time
import os
from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *


def _init_metrics():
    return {
        "Entity1": 0.0,         # ms
        "Entity2": 0.0,         # ms
        "Entity3": 0.0,         # ms
        "total_time": None,     # ms
        "success": False,
        "error": None,
        "Entity1_success": False,
        "Entity2_success": False,
        "Entity3_success": False,
    }


def _elapsed_ms(start_time, end_time):
    return round((end_time - start_time) * 1000, 4)


# =========================================
# Entity1（原 Vehicle）
# =========================================
def Vehicle_Entity(uav_ip, uav_port, metrics):
    try:
        # =========================
        # 第一段：本地准备 Msg1 + 发送给 Entity2
        # =========================
        seg1_start = time.perf_counter()

        TID_i = Read_data("Miao_Vehicle_Storage", "TID_i")
        UID_k = Read_data("Miao_UAV_Storage", "UID_k")
        VF_i = Read_data("Miao_Vehicle_Storage", "VF_i")
        b_i = Read_data("Miao_Vehicle_Storage", "b_i")
        P = Get_base_point()

        u_i = Generate_Nonce()
        T1 = Generate_Timestamp()

        Z1 = Hash(Concat_Data(TID_i, UID_k, VF_i, T1))
        Z2 = Hash(Concat_Data(b_i, u_i))
        Z3 = ECC_Point_scalar_multiply(P, Hash(Concat_Data(b_i, u_i)))
        Z4 = Scalar_add(b_i, Scalar_mul(Z1, Z2))

        msg1 = Create_message({"TID_i": TID_i, "Z3": Z3, "Z4": Z4, "T1": T1})

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((uav_ip, uav_port))
            s.sendall(msg1)

            seg1_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg1_start, seg1_end)

            # 等待最终响应（不计时）
            resp_data = s.recv(2048)
            msg_final = Parse_Message(resp_data)

        # =========================
        # 第二段：收到最终响应后处理
        # =========================
            seg2_start = time.perf_counter()

            Z7 = msg_final.get("Z7")
            N_j = msg_final.get("N_j")
            Z12 = msg_final.get("Z12")
            V_k = msg_final.get("V_k")
            T3 = msg_final.get("T3")
            T4 = msg_final.get("T4")

            Z6_prime = ECC_Point_scalar_multiply(N_j, Hash(Concat_Data(b_i, u_i)))

            TID_new = Xor_Data(Hash(Z6_prime), Z7)

            VD_i = Read_data("Miao_Vehicle_Storage", "VD_i")

            Z10 = Hash(Concat_Data(TID_i, TID_new, VF_i, VD_i, Z6_prime, T3))

            Z11 = ECC_Point_scalar_multiply(V_k, Hash(Concat_Data(b_i, u_i)))

            SK_v = Hash(Concat_Data(UID_k, Z11))

            Z12_prime = Hash(Concat_Data(UID_k, SK_v, Z10, T4))

            if Z12_prime == Z12:
                print("Entity1: 认证成功！会话密钥 SK 已生成。")
            else:
                print("Entity1: 认证失败！")

            print(f"SK computed by Entity1 is {SK_v}")

            Store_data("Miao_Vehicle_Storage","TID_i", TID_new)

            seg2_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg2_start, seg2_end)

            metrics["Entity1"] = round(metrics["Entity1"], 4)
            metrics["Entity1_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity1 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity2（原 UAV）
# =========================================
def UAV_Entity(listen_port, rsu_ip, rsu_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg1（不计时）
                data = conn.recv(2048)

                # =========================
                # 第一段：收到 Msg1 后处理并转发给 Entity3
                # =========================
                seg1_start = time.perf_counter()

                msg1 = Parse_Message(data)

                TID_i = msg1.get("TID_i")
                Z3 = msg1.get("Z3")
                Z4 = msg1.get("Z4")
                T1 = msg1.get("T1")

                UID_k = Read_data("Miao_UAV_Storage", "UID_k")

                VE_k = Read_data("Miao_UAV_Storage", "VE_k")

                P = Get_base_point()


                v_k = Generate_scalar()

                T2 = Generate_Timestamp()

                V_k = ECC_Point_scalar_multiply(P, v_k)

                Z5 = Hash(Concat_Data(UID_k, VE_k, T2))

                msg2 = Create_message({
                    "TID_i": TID_i,
                    "Z3": Z3,
                    "Z4": Z4,
                    "V_k": V_k,
                    "Z5": Z5,
                    "UID_k": UID_k,
                    "T1": T1,
                    "T2": T2
                })

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as rsu_sock:
                    rsu_sock.connect((rsu_ip, rsu_port))
                    rsu_sock.sendall(msg2)

                    seg1_end = time.perf_counter()
                    metrics["Entity3"] += _elapsed_ms(seg1_start, seg1_end)

                    # 等待 Entity3 响应（不计时）
                    rsu_resp = rsu_sock.recv(2048)
                    msg3 = Parse_Message(rsu_resp)

                # =========================
                # 第二段：收到 Msg3 后处理并发回 Entity1
                # =========================
                    seg2_start = time.perf_counter()

                    Z7 = msg3.get("Z7")
                    Z9 = msg3.get("Z9")
                    Z10 = msg3.get("Z10")
                    N_j = msg3.get("N_j")
                    T3 = msg3.get("T3")

                    Z8_prime = ECC_Point_scalar_multiply(N_j, v_k)

                    Z9_prime = Hash(Concat_Data(UID_k, Z8_prime, VE_k, T3))

                    if Z9_prime == Z9:
                        print("Z9 has been checked")
                    else:
                        print("Z9 has been NOT checked")
                        raise ValueError("Entity2 Z9 verification failed")

                    Z11 = ECC_Point_scalar_multiply(Z3, v_k)

                    T4 = Generate_Timestamp()

                    SK_u = Hash(Concat_Data(UID_k, Z11))

                    print(f"SK computed by Entity2 is {SK_u}")

                    Z12 = Hash(Concat_Data(UID_k, SK_u, Z10, T4))

                    final_dict = {
                    "Z7": Z7,
                    "N_j": N_j,
                    "Z12": Z12,
                    "V_k": V_k,
                    "T3": T3,
                    "T4": T4
                    }
                    conn.sendall(Create_message(final_dict))

                    print("Entity2: 认证成功并已转发给 Entity1。")

                    seg2_end = time.perf_counter()
                    metrics["Entity3"] += _elapsed_ms(seg2_start, seg2_end)

            metrics["Entity3"] = round(metrics["Entity3"], 4)
            metrics["Entity3_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity3 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity3（原 RSU）
# =========================================
def RSU_Entity(listen_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg2（不计时）
                data = conn.recv(2048)

                # =========================
                # 收到 Msg2 后开始计时：处理 + 发响应
                # =========================
                seg_start = time.perf_counter()

                msg2 = Parse_Message(data)

                TID_i = msg2.get("TID_i")
                Z3 = msg2.get("Z3")
                Z4 = msg2.get("Z4")
                V_k = msg2.get("V_k")
                Z5 = msg2.get("Z5")
                UID_k = msg2.get("UID_k")
                T1 = msg2.get("T1")
                T2 = msg2.get("T2")

                TID_i_read = Read_data("Miao_RSU_Storage", "TID_i")

                if TID_i_read == TID_i:
                    print("TID_i has been found")
                else:
                    raise ValueError("Entity3 could not find TID_i")

                c_i = Read_data("Miao_RSU_Storage", "c_i")
                B_i = Read_data("Miao_RSU_Storage", "B_i")
                h = Read_data("Miao_RSU_Storage", "h")

                decryption_key = Hash(h)[:16]

                Decryted_data = AES_Dec(TID_i_read, decryption_key)

                VD_i = Xor_Data(Decryted_data, c_i)

                VF_ii = Hash(Concat_Data(VD_i, h))

                Z1_prime = Hash(Concat_Data(TID_i, UID_k, VF_ii, T1))

                P = Get_base_point()

                check_point = ECC_Points_sub(
                    ECC_Point_scalar_multiply(P, Z4),
                    ECC_Point_scalar_multiply(Z3, Z1_prime)
                )

                if check_point == B_i:
                    print("B_i has been checked")
                else:
                    print("B_i has not been checked")
                    raise ValueError("Entity3 B_i verification failed")

                a_j = Read_data("Miao_RSU_Storage", "a_j")

                VE_k_prime = Hash(Concat_Data(UID_k, a_j))

                Z_5_prime = Hash(Concat_Data(UID_k, VE_k_prime, T2))

                if Z_5_prime == Z5:
                    print("UAV has been checked")
                else:
                    print("UAV has not been checked")
                    raise ValueError("Entity3 UAV verification failed")

                n_j = Generate_scalar()

                m_i = Generate_Nonce()

                T3 = Generate_Timestamp()

                Z6 = ECC_Point_scalar_multiply(Z3, n_j)

                TID_new = AES_Enc(Xor_Data(VD_i, m_i),decryption_key)

                Z7 = Xor_Data(Hash(Z6), TID_new)

                Z8 = ECC_Point_scalar_multiply(V_k, n_j)

                Z9 = Hash(Concat_Data(UID_k, Z8, VE_k_prime, T3))

                Z10 = Hash(Concat_Data(TID_i, TID_new, VF_ii, VD_i, Z6, T3))

                N_j = ECC_Point_scalar_multiply(P, n_j)

                resp = Create_message({
                    "Z7": Z7,
                    "Z9": Z9,
                    "Z10": Z10,
                    "N_j": N_j,
                    "T3": T3
                })

                Store_data("Miao_RSU_Storage", "TID_i", TID_new)
                Store_data("Miao_RSU_Storage", "c_i", m_i)

                conn.sendall(resp)

                print("Entity3: 身份验证通过，响应已发送。")

                seg_end = time.perf_counter()
                metrics["Entity2"] = _elapsed_ms(seg_start, seg_end)

        metrics["Entity2"] = round(metrics["Entity2"], 4)
        metrics["Entity2_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity2 protocol error: {e}"
        print(metrics["error"])


# =========================================
# 主协议入口
# =========================================
def Miao_protocol():
    metrics = _init_metrics()

    entity1_ip = '127.0.0.1'
    entity2_port = 5001
    entity3_port = 5002

    entity3_thread = threading.Thread(
        target=RSU_Entity,
        args=(entity3_port, metrics)
    )
    entity2_thread = threading.Thread(
        target=UAV_Entity,
        args=(entity2_port, '127.0.0.1', entity3_port, metrics)
    )
    entity1_thread = threading.Thread(
        target=Vehicle_Entity,
        args=(entity1_ip, entity2_port, metrics)
    )

    entity3_thread.start()
    time.sleep(0.25)

    entity2_thread.start()
    time.sleep(0.25)

    entity1_thread.start()

    entity3_thread.join()
    entity2_thread.join()
    entity1_thread.join()

    metrics["Entity1"] = round(metrics["Entity1"], 4)
    metrics["Entity2"] = round(metrics["Entity2"], 4)
    metrics["Entity3"] = round(metrics["Entity3"], 4)

    metrics["total_time"] = round(
        metrics["Entity1"] + metrics["Entity2"] + metrics["Entity3"],
        4
    )

    if (
        metrics["Entity1_success"]
        and metrics["Entity2_success"]
        and metrics["Entity3_success"]
        and metrics["error"] is None
    ):
        metrics["success"] = True

    return metrics


if __name__ == "__main__":
    result = Miao_protocol()
    print("\n===== Miao Protocol Timing Result =====")
    print(f"Entity1 Time : {result['Entity1']:.4f} ms")
    print(f"Entity2 Time : {result['Entity2']:.4f} ms")
    print(f"Entity3 Time : {result['Entity3']:.4f} ms")
    print(f"Total Time   : {result['total_time']:.4f} ms")
    print(f"Success      : {result['success']}")
    print(f"Error        : {result['error']}")