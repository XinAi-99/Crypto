from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *

s = Generate_Nonce()

h = Generate_Nonce()

RID_k = Generate_Nonce()

CH_k = Generate_Nonce()

s_k = Hash(Concat_Data(s,RID_k,h))

Store_data("Choi_RSU","RID_k",RID_k)

Store_data("Choi_RSU","s_k",s_k)

Store_data("Choi_RSU","CH_k",CH_k)

Store_data("Choi_Ta","s",s)

UID_j = Generate_Nonce()

r_ta_1 = Generate_Nonce()

K_ur =  Hash(Concat_Data(UID_j,s,r_ta_1))

Store_data("Choi_RSU","UID_j",UID_j)

Store_data("Choi_Drone","UID_j",UID_j)

Store_data("Choi_Drone","K_ur",K_ur)

Store_data("Choi_RSU","K_ur",K_ur)

VID_i  = Generate_Nonce()

CH_i  = Generate_Nonce()

RE_i = Ideal_PUF(CH_i)

R_i,H_i = Gen(RE_i)

r_ta_2 = Generate_Nonce()

TID_i = Generate_Nonce()

K_kr = Hash(Concat_Data(VID_i,s,r_ta_2))

Store_data("Choi_RSU","K_kr",K_kr)

Store_data("Choi_RSU","CH_i",CH_i)

Store_data("Choi_RSU","TID_i",TID_i)

Store_data("Choi_RSU","R_I",R_i)

Store_data("Choi_Vehicle","TID_i",TID_i)

Store_data("Choi_Vehicle","K_kr",K_kr)

Store_data("Choi_Vehicle","H_i",H_i)

RE_K = Ideal_PUF(CH_k)

VR_i = Xor_Data(Concat_Data(K_kr,CH_i,R_i),Hash(Concat_Data(RE_K,s_k)))

Store_data("Choi_RSU","VR_i",VR_i)








