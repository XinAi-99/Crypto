import time
from Standardized_Cryptographic_Primitives import *

Data = Hash(Generate_Nonce())

Bio = Generate_Nonce()

CH = Generate_Nonce()

k1  =Generate_scalar()

k2 =Generate_scalar()


k3 =Generate_scalar()

p = Get_base_point()

P1 = ECC_Point_scalar_multiply(p,k1)

P2 = ECC_Point_scalar_multiply(p,k2)

IV = Generate_Nonce()

AD = Generate_Nonce()

K = Generate_Nonce()

K_enc = Hash(Generate_Nonce())

nonce = Generate_Nonce()

X = Hash(Generate_Nonce())


def fuzzy_extractor(Bio):

    Bk,hd = Gen(Bio)

    BK2 = Rep(Bio,hd)

def ascon_test(IV,AD,K,PT):

    CT = ASCON_Encrypt(IV,AD,K,PT)

    PT2 = ASCON_Decrypt(IV,AD,K,CT)

def AES_test(Data,K):

    ct = AES_Enc(Data,K)

    pt = AES_Dec(ct,K)

def AEGIS_test(IV,AD,K,PT):

    CT = AEGIS128_Encrypt(PT,AD,IV,K)

    PT = AEGIS128_Decrypt(CT,AD,IV,K)



# ====== 将函数和参数统一封装 ======
# 这里用 lambda 的好处是：即使每个函数参数不同，也可以统一调用
functions = [
    lambda: Hash(Data),         # 1 Hash
    lambda: fuzzy_extractor(Bio), # 2 Fuzzy extractor
    lambda: Ideal_PUF(CH),  # 3 PUF
    lambda: ECC_Points_add(P1,P2), #4 ECC Point add
    lambda: ECC_Point_scalar_multiply(p,k3),#5 ECC point multiplication
    lambda: ascon_test(IV,AD,K,Data), # 6 ascon
    lambda: AES_test(Data,K_enc), #7 AES
    lambda: Chebyshev_chaotic_map(nonce,X), #8 Chaotic map
    lambda:AEGIS_test(IV,AD,K,Data)
]


# ====== 计时函数 ======
def measure_average_time(n, repeat=100):
    if not (1 <= n <= len(functions)):
        print(f"输入错误：n 必须在 1 到 {len(functions)} 之间")
        return

    target_func = functions[n - 1]
    total_time = 0.0

    for _ in range(repeat):
        start = time.perf_counter()
        target_func()
        end = time.perf_counter()
        total_time += (end - start)

    avg_time_ms = (total_time / repeat) * 1000
    print(f"第{n}个函数平均执行时间：{avg_time_ms:.4f} ms")


# ====== 主程序 ======

if __name__ == "__main__":
    n = int(input("请输入要测试的函数编号 n（1~20）："))
    measure_average_time(n)  # 直接调用函数，去掉等号