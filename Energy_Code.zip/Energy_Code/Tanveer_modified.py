import threading
import socket
import os
import time
from Standardized_Message import *
from Standardized_Cryptographic_Primitives import *


s_rc_file = "18_S_RC_database"
drone_file = "18_drone_database"
user_db = "18_user_database"


def _init_metrics():
    return {
        "Entity1": 0.0,         # ms -> User
        "Entity2": 0.0,         # ms -> Server
        "Entity3": 0.0,         # ms -> Drone
        "total_time": None,     # ms
        "success": False,
        "error": None,
        "Entity1_success": False,
        "Entity2_success": False,
        "Entity3_success": False,
    }


def _elapsed_ms(start_time, end_time):
    return round((end_time - start_time) * 1000, 4)


# =========================================
# Entity1（User）
# 消息流：
# 1) Entity1 -> Entity2 : Msg1
# 3) Entity2 -> Entity1 : Msg3
# =========================================
def User_Entity(S_ip, S_port, metrics):
    try:

        rp = Read_data(user_db, "rp")
        CT_r = Read_data(user_db, "CT_r")
        RN_r = Read_data(user_db, "RN_r")
        UI_UR = Read_data(user_db, "UI_UR")
        TC_UR = Read_data(user_db, "TC_UR")
        PIDk = Read_data(user_db, "PIDk")
        user_id = Read_data(user_db, "user_id")
        biometric_input = Read_data(user_db, "biometric")
        password_input = Read_data(user_db, "password")

        AD_r_stored = Read_data(user_db, "AD_r")
        IV_r_stored = Read_data(user_db, "IV_r")
        k_r_stored = Read_data(user_db, "k_r")

        Bmk_UR = Rep(biometric_input, rp)

        D_bytes = Concat_Data(Hash(Concat_Data(Bmk_UR, password_input)), RN_r)
        D1_bytes = D_bytes[:16]
        D2_bytes = D_bytes[16:32]

        k_l_bytes = Xor_Data(D1_bytes, D2_bytes)
        k_l_bytes = k_l_bytes[:16]

        E_bytes = Concat_Data(Hash(user_id), RN_r)
        E1_bytes = E_bytes[:16]
        E2_bytes = E_bytes[16:32]

        AD_l_bytes = Xor_Data(E1_bytes, E2_bytes)
        AD_l_bytes = AD_l_bytes[:16]

        IV_l_bytes = RN_r[:16]

        PT_r_bytes = AEGIS128_Decrypt(CT_r, AD_l_bytes, IV_l_bytes, k_l_bytes)

        PT_UI = PT_r_bytes[:16]
        PT_TC = PT_r_bytes[16:32]
        PT_PID = PT_r_bytes[32:48]

        if PT_UI == UI_UR and PT_TC == TC_UR and PT_PID == PIDk:
            print("User login successfully")
        else:
            print("User login failed")
            os._exit(1)

        # =========================
        # 第一段：生成并发送 Msg1 给 Entity2
        # =========================
        seg1_start = time.perf_counter()

        T_ul = int(time.time()).to_bytes(4, "big")
        RN_ul = Generate_Nonce()
        Sku = Generate_scalar()

        G_bytes = Read_data(s_rc_file, "G")
        Puuk = ECC_Point_scalar_multiply(G_bytes, Sku)

        Pusk = Read_data(s_rc_file, "Pusk")
        K_ul = ECC_Point_scalar_multiply(Pusk, Sku)

        G_ul = Hash(Concat_Data(T_ul, K_ul))

        UI_PID = Concat_Data(UI_UR, PIDk)
        G_ul2 = Xor_Data(UI_PID, G_ul)

        G_ul2_mid = len(G_ul2) // 2
        G_ul2_1 = G_ul2[:G_ul2_mid]
        G_ul2_2 = G_ul2[G_ul2_mid:]

        AD_ul = Xor_Data(G_ul2_1, G_ul2_2)
        AD_ul = AD_ul[:16]

        IV_ul = G_ul[:16]

        CT_ul = AEGIS128_Encrypt(RN_ul, AD_ul, IV_ul, TC_UR)

        msg1 = Create_message({
            "T_ul": T_ul,
            "G_ul2": G_ul2,
            "CT_ul": CT_ul,
            "Puuk": Puuk
        })

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((S_ip, S_port))

            print("Entity1 sends Msg1 to Entity2")

            s.sendall(msg1)

            seg1_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg1_start, seg1_end)

            # 等待最终响应（不计时）
            resp_data = s.recv(4096)
            msg3 = Parse_Message(resp_data)

            # =========================
            # 第二段：接收并处理 Msg3
            # =========================
            seg2_start = time.perf_counter()

            print(f"Entity1 has received {msg3}")

            T_d3 = msg3.get("T_d3")
            CT_d3 = msg3.get("CT_d3")
            Pudk = msg3.get("Pudk")

            Suk = ECC_Point_scalar_multiply(Pudk, Sku)

            X_ur = Hash(Concat_Data(K_ul, RN_ul, TC_UR))
            Q_d3 = Hash(Concat_Data(Suk, X_ur, T_d3, Pudk))

            K_6 = Q_d3[:16]

            X_d3 = AEGIS128_Decrypt(CT_d3, b'', K_6, K_6)

            SK_u = Hash(Concat_Data(Suk, X_ur, T_d3, Pudk, X_d3))

            print(f"SK_u computed by user is {SK_u}")
            print("Entity1 authentication flow completed successfully")

            seg2_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity1"] = round(metrics["Entity1"], 4)
        metrics["Entity1_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity1 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity2（Server）
# 消息流：
# 1) 接收 Entity1 的 Msg1
# 2) Entity2 -> Entity3 : Msg2
# 3) 接收 Entity3 的 Msg3
# 4) Entity2 -> Entity1 : 转发 Msg3
# =========================================
def Server_Entity(S_ip, S_port, Dk_ip, Dk_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind((S_ip, S_port))
            server_sock.listen(1)

            print("Entity2 waiting for Entity1 connection")

            conn, addr = server_sock.accept()

            with conn:
                # 等待接收 Msg1（不计时）
                data = conn.recv(4096)

                # =========================
                # 第一段：处理 Msg1 并发送 Msg2 给 Entity3
                # =========================
                seg1_start = time.perf_counter()

                msg1 = Parse_Message(data)

                print(f"Entity2 has received {msg1}")

                T_ul = msg1.get("T_ul")
                G_ul2 = msg1.get("G_ul2")
                CT_ul = msg1.get("CT_ul")
                Puuk = msg1.get("Puuk")

                Sks = Read_data(s_rc_file, "Sks")
                K_sl = ECC_Point_scalar_multiply(Puuk, Sks)

                G_sl = Hash(Concat_Data(T_ul, K_sl))
                UI_PID = Xor_Data(G_ul2, G_sl)

                UI_UR = UI_PID[:16]
                PIDk = UI_PID[16:]

                stored_UI = Read_data(s_rc_file, "UI_UR")

                if UI_UR == stored_UI:
                    print("UI_UR has been authenticated")
                else:
                    print("UI_UR has been not authenticated")
                    os._exit(1)

                CT_s = Read_data(s_rc_file, "CT_s")
                RN_a = Read_data(s_rc_file, "RN_a")

                AA = Concat_Data(Sks, RN_a)
                IV_sl = RN_a[:16]

                AA1 = AA[:16]
                AA2 = AA[16:32]

                k_sl = Xor_Data(AA1, AA2)
                k_sl = k_sl[:16]

                AD_s = UI_UR
                PT_s = AEGIS128_Decrypt(CT_s, AD_s, IV_sl, k_sl)

                TC_UR = PT_s[:16]
                PIDk_stored = PT_s[16:32]
                TS_Dk = PT_s[32:48]

                G_ul2_mid = len(G_ul2) // 2
                G_ul2_1 = G_ul2[:G_ul2_mid]
                G_ul2_2 = G_ul2[G_ul2_mid:]

                AD_ul = Xor_Data(G_ul2_1, G_ul2_2)
                AD_ul = AD_ul[:16]
                IV_ul = G_sl[:16]

                RN_ul = AEGIS128_Decrypt(CT_ul, AD_ul, IV_ul, TC_UR)

                print("Entity2: user message decrypted successfully")

                T_s2 = int(time.time()).to_bytes(4, "big")
                RN_sl = Generate_Nonce()
                RN_s2 = Generate_Nonce()[:8]

                X_sl = Hash(Concat_Data(K_sl, RN_ul, TC_UR))

                AD_s2 = Concat_Data(T_s2, RN_s2, T_s2)
                IV_s3 = Xor_Data(PIDk, AD_s2)
                IV_s3 = IV_s3[:16]

                PT_sl = Concat_Data(X_sl, RN_sl)

                CT_s2 = AEGIS128_Encrypt(PT_sl, AD_s2, IV_s3, TS_Dk)

                msg2 = Create_message({
                    "T_s2": T_s2,
                    "CT_s2": CT_s2,
                    "RN_s2": RN_s2,
                    "Puuk": Puuk
                })

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as drone_sock:
                    drone_sock.connect((Dk_ip, Dk_port))

                    print("Entity2 sends Msg2 to Entity3")

                    drone_sock.sendall(msg2)

                    seg1_end = time.perf_counter()
                    metrics["Entity2"] += _elapsed_ms(seg1_start, seg1_end)

                    # 等待 Entity3 响应（不计时）
                    drone_resp = drone_sock.recv(4096)

                    if not drone_resp:
                        print("Entity2: no response from Entity3")
                        os._exit(1)

                    msg3 = Parse_Message(drone_resp)

                    # =========================
                    # 第二段：处理 Msg3 并转发给 Entity1
                    # =========================
                    seg2_start = time.perf_counter()

                    print(f"Entity2 has received {msg3}")

                    conn.sendall(drone_resp)

                    print("Entity2 forwards Msg3 to Entity1")
                    print("Entity2 authentication flow completed successfully")

                    seg2_end = time.perf_counter()
                    metrics["Entity2"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity2"] = round(metrics["Entity2"], 4)
        metrics["Entity2_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity2 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity3（Drone）
# 消息流：
# 2) 接收 Entity2 的 Msg2
# 3) Entity3 -> Entity2 : Msg3
# =========================================
def Drone_Entity(Dk_ip, Dk_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind((Dk_ip, Dk_port))
            server_sock.listen(1)

            print("Entity3 waiting for Entity2 connection")

            conn, addr = server_sock.accept()

            with conn:
                # 等待接收 Msg2（不计时）
                data = conn.recv(4096)

                # =========================
                # 收到 Msg2 后开始计时：处理 + 发送 Msg3
                # =========================
                seg_start = time.perf_counter()

                msg2 = Parse_Message(data)

                print(f"Entity3 has received {msg2}")

                T_s2 = msg2.get("T_s2")
                CT_s2 = msg2.get("CT_s2")
                RN_s2 = msg2.get("RN_s2")
                Puuk = msg2.get("Puuk")

                PIDk = Read_data(drone_file, "PIDk")
                TS_Dk = Read_data(drone_file, "TS_Dk")

                AD_d1 = Concat_Data(T_s2, RN_s2, T_s2)
                IV_d1 = Xor_Data(PIDk, AD_d1)
                IV_d1 = IV_d1[:16]

                PT_s1 = AEGIS128_Decrypt(CT_s2, AD_d1, IV_d1, TS_Dk)

                X_sl = PT_s1[:32]
                RN_sl = PT_s1[32:48]

                T_d3 = int(time.time()).to_bytes(4, "big")
                RN_d3 = Generate_Nonce()
                Skd = Generate_scalar()

                G_bytes = Read_data(s_rc_file, "G")
                Pudk = ECC_Point_scalar_multiply(G_bytes, Skd)

                Suk = ECC_Point_scalar_multiply(Puuk, Skd)

                Q_d3 = Hash(Concat_Data(Suk, X_sl, T_d3, Pudk))
                K_5 = Q_d3[:16]

                RN_combined = Xor_Data(RN_d3, RN_sl)
                TS_T = Concat_Data(TS_Dk, T_s2)

                X_d3 = Hash(Concat_Data(RN_combined, TS_T))
                CT_d3 = AEGIS128_Encrypt(X_d3, b'', K_5, K_5)

                SK_d = Hash(Concat_Data(Suk, X_sl, T_d3, Pudk, X_d3))

                print(f"SK_d computed by drone is {SK_d}")

                msg3 = Create_message({
                    "T_d3": T_d3,
                    "CT_d3": CT_d3,
                    "Pudk": Pudk
                })

                conn.sendall(msg3)

                print("Entity3 sends Msg3 to Entity2")
                print("Entity3 authentication flow completed successfully")

                seg_end = time.perf_counter()

                metrics["Entity3"] = _elapsed_ms(seg_start, seg_end)

        metrics["Entity3"] = round(metrics["Entity3"], 4)
        metrics["Entity3_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity3 protocol error: {e}"
        print(metrics["error"])


# =========================================
# 主协议入口
# =========================================
def Tanveer_protocol():
    metrics = _init_metrics()

    U_i_ip = "127.0.50.1"
    U_i_port = 13502

    S_ip = "127.0.50.1"
    S_port = 13503

    Dk_ip = "127.0.50.1"
    Dk_port = 13504

    entity3_thread = threading.Thread(
        target=Drone_Entity,
        args=(Dk_ip, Dk_port, metrics)
    )

    entity2_thread = threading.Thread(
        target=Server_Entity,
        args=(S_ip, S_port, Dk_ip, Dk_port, metrics)
    )

    entity1_thread = threading.Thread(
        target=User_Entity,
        args=(S_ip, S_port, metrics)
    )

    entity3_thread.start()
    time.sleep(0.25)

    entity2_thread.start()
    time.sleep(0.25)

    entity1_thread.start()

    entity3_thread.join()
    entity2_thread.join()
    entity1_thread.join()

    metrics["Entity1"] = round(metrics["Entity1"], 4)
    metrics["Entity2"] = round(metrics["Entity2"], 4)
    metrics["Entity3"] = round(metrics["Entity3"], 4)

    metrics["total_time"] = round(
        metrics["Entity1"] + metrics["Entity2"] + metrics["Entity3"],
        4
    )

    if (
        metrics["Entity1_success"]
        and metrics["Entity2_success"]
        and metrics["Entity3_success"]
        and metrics["error"] is None
    ):
        metrics["success"] = True

    return metrics


if __name__ == "__main__":
    result = Tanveer_protocol()
    print("\n===== Tanveer Protocol Timing Result =====")
    print(f"Entity1 Time : {result['Entity1']:.4f} ms")
    print(f"Entity2 Time : {result['Entity2']:.4f} ms")
    print(f"Entity3 Time : {result['Entity3']:.4f} ms")
    print(f"Total Time   : {result['total_time']:.4f} ms")
    print(f"Success      : {result['success']}")
    print(f"Error        : {result['error']}")