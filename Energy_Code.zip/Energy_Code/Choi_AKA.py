import threading
import socket
import time
from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *


def _init_metrics():
    return {
        "Entity1": 0.0,         # ms   -> Vehicle
        "Entity2": 0.0,         # ms   -> RSU
        "Entity3": 0.0,         # ms   -> Drone
        "total_time": None,     # ms
        "success": False,
        "error": None,
        "Entity1_success": False,
        "Entity2_success": False,
        "Entity3_success": False,
    }


def _elapsed_ms(start_time, end_time):
    return round((end_time - start_time) * 1000, 4)


# =========================================
# Entity1（Vehicle）
# 消息流：
# 1) Entity1 -> Entity3 : r1
# 4) Entity3 -> Entity1 : r4
# =========================================
def Vehicle_Entity(drone_ip, drone_port, metrics):
    try:
        # =========================
        # 第一段：生成随机值并发送给 Drone
        # =========================
        seg1_start = time.perf_counter()

        UID_j = Read_data("Choi_Drone","UID_j")

        TID_i = Read_data("Choi_Vehicle","TID_i")

        K_kr = Read_data("Choi_Vehicle","K_kr")

        u_i = Generate_Nonce()

        T1 = Generate_Timestamp()

        M_1 =Xor_Data(u_i,Hash(Concat_Data(TID_i,UID_j,K_kr,T1)))

        C_1 = Hash(Concat_Data(TID_i,UID_j,u_i))

        V_1 = Hash(Concat_Data(TID_i,UID_j,u_i,K_kr,T1))


        msg1 = Create_message({
           "TID_i": TID_i,
            "UID_j": UID_j,
            "M_1": M_1,
            "C_1": C_1,
            "V_1": V_1,
            "T1": T1,
        })

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((drone_ip, drone_port))
            s.sendall(msg1)

            seg1_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg1_start, seg1_end)

            # 等待最终响应（不计时）
            resp_data = s.recv(2048)
            msg4 = Parse_Message(resp_data)

            # =========================
            # 第二段：收到最终响应后处理
            # =========================
            seg2_start = time.perf_counter()

            M_5 = msg4.get("M_5")

            M_6 = msg4.get("M_6")

            M_7 = msg4.get("M_7")

            V_5 = msg4.get("V_5")

            T3 = msg4.get("T3")

            T4 = msg4.get("T4")

            CH_i = Recover_Data(M_5,16,Hash(Concat_Data(TID_i,UID_j,u_i,K_kr,T3)))

            RE = Ideal_PUF(CH_i)

            H_i = Read_data("Choi_Vehicle","H_i")

            R_i = Rep(RE,H_i)

            value = Xor_Data(M_6,Hash(Concat_Data(TID_i,UID_j,R_i,K_kr,T3)))

            v_j = Recover_Data(M_7,16,Hash(Concat_Data(TID_i,UID_j,value,R_i,K_kr,T3)))

            TID_i_new = Hash(Concat_Data(TID_i,u_i,T3))

            Store_data("Choi_Vehicle", "TID_i", TID_i_new)

            V_4 = Hash(Concat_Data(TID_i_new,R_i,u_i,value,K_kr,v_j,T3))

            SK = Hash(Concat_Data(u_i,value,v_j,UID_j,TID_i,T4))

            print(f"SK computed by user is {SK}")

            V_55 = Hash(Concat_Data(TID_i,UID_j,V_4,SK,T4))

            if V_55==V_5:

                print("V5 has been checked")

            else:

                print("V5 has been NOT checked")

                os._exit(1)

            print("Entity1: 已收到来自 Entity3 的最终消息。")

            seg2_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity1"] = round(metrics["Entity1"], 4)
        metrics["Entity1_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity1 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity3（Drone）
# 消息流：
# 1) 接收 Entity1 的 r1
# 2) Entity3 -> Entity2 : r2
# 3) 接收 Entity2 的 r3
# 4) Entity3 -> Entity1 : r4
# =========================================
def Drone_Entity(listen_port, rsu_ip, rsu_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg1（不计时）
                data = conn.recv(2048)

                # =========================
                # 第一段：处理来自 Vehicle 的消息，并转发给 RSU
                # =========================
                seg1_start = time.perf_counter()

                msg1 = Parse_Message(data)

                TID_i = msg1.get("TID_i")

                UID_j = msg1.get("UID_j")

                M_1 = msg1.get("M_1")

                C_1 = msg1.get("C_1")

                V_1 = msg1.get("V_1")

                T1 = msg1.get("T1")

                print("Entity3: 已收到来自 Entity1 的消息。")

                v_j = Generate_Nonce()

                T2 = Generate_Timestamp()

                K_ur = Read_data("Choi_Drone","K_ur")

                M_2 = Xor_Data(v_j,Hash(Concat_Data(TID_i,UID_j,K_ur,T2)))

                V_2 = Hash(Concat_Data(TID_i,UID_j,V_1,v_j,K_ur,T2))



                msg2 = Create_message({
                    "TID_i": TID_i,
                    "UID_j": UID_j,
                    "M_1": M_1,
                    "M_2": M_2,
                    "V_2": V_2,
                    "T1": T1,
                    "T2": T2
                })

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as rsu_sock:
                    rsu_sock.connect((rsu_ip, rsu_port))
                    rsu_sock.sendall(msg2)

                    seg1_end = time.perf_counter()
                    metrics["Entity3"] += _elapsed_ms(seg1_start, seg1_end)

                    # 等待 Entity2 响应（不计时）
                    rsu_resp = rsu_sock.recv(2048)
                    msg3 = Parse_Message(rsu_resp)

                    # =========================
                    # 第二段：处理来自 RSU 的消息，并发回 Vehicle
                    # =========================
                    seg2_start = time.perf_counter()

                    M_3= msg3.get("M_3")

                    M_4 = msg3.get("M_4")

                    M_5 = msg3.get("M_5")

                    M_6 = msg3.get("M_6")

                    M_7 = msg3.get("M_7")

                    V_3 = msg3.get("V_3")

                    V_4 = msg3.get("V_4")

                    T3 = msg3.get("T3")

                    value = Xor_Data(M_3,Hash(Concat_Data(TID_i,UID_j,v_j,K_ur,T3)))

                    u_i = Recover_Data(M_4,16,Hash(Concat_Data(TID_i,UID_j,value,K_ur,T3)))

                    V_33 = Hash(Concat_Data(TID_i,UID_j,v_j,value,K_ur,u_i,T3))

                    if V_3==V_33:

                        print("V3 has been checked")

                    else:

                        print("V3 has been NOT checked")

                        os._exit(1)


                    C_11 = Hash(Concat_Data(TID_i,UID_j,u_i))

                    if C_11 == C_1:

                        print("C_1 has been checked")

                    else:

                        print("C_1 has been NOT checked")

                        os._exit(1)
                    T4 = Generate_Timestamp()

                    SK = Hash(Concat_Data(u_i,value,v_j,UID_j,TID_i,T4))

                    print(f"SK computed by drone is {SK}")

                    V_5 = Hash(Concat_Data(TID_i,UID_j,V_4,SK,T4))

                    msg4 = Create_message({
                        "M_5":M_5,
                        "M_6":M_6,
                        "M_7":M_7,
                        "V_5":V_5,
                        "T3": T3,
                        "T4": T4
                    })

                    conn.sendall(msg4)

                    print("Entity3: 已将最终消息发送给 Entity1。")

                    seg2_end = time.perf_counter()

                    metrics["Entity3"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity3"] = round(metrics["Entity3"], 4)
        metrics["Entity3_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity3 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity2（RSU）
# 消息流：
# 2) 接收 Entity3 的 r2
# 3) Entity2 -> Entity3 : r3
# =========================================
def RSU_Entity(listen_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg2（不计时）
                data = conn.recv(2048)

                # =========================
                # 收到 Msg2 后处理并返回 Msg3
                # =========================
                seg_start = time.perf_counter()

                msg2 = Parse_Message(data)

                TID_i = msg2.get("TID_i")

                UID_j = msg2.get("UID_j")

                M_1 = msg2.get("M_1")

                M_2 = msg2.get("M_2")

                V_2 = msg2.get("V_2")

                T1 = msg2.get("T1")

                T2 = msg2.get("T2")

                print("Entity2: 已收到来自 Entity3 的消息。")

                TID_i_read = Read_data("Choi_RSU","TID_i")

                if TID_i_read == TID_i:

                    print("TID_i has been found")

                else:

                    print("TID_i has been NOT found")

                    os._exit(1)

                VR_i = Read_data("Choi_RSU","VR_i")

                CH_k = Read_data("Choi_RSU","CH_k")

                RE_k = Ideal_PUF(CH_k)

                s_k = Read_data("Choi_RSU","s_k")

                Data = Xor_Data(VR_i,Hash(Concat_Data(RE_k,s_k)))

                Data_split = Split_Data(Data,32,16,32)

                K_VR = Data_split[0]

                CH_i = Data_split[1]

                R_i = Data_split[2]

                u_i = Recover_Data(M_1,16,Hash(Concat_Data(TID_i,UID_j,K_VR,T1)))

                V_1_re = Hash(Concat_Data(TID_i,UID_j,u_i,K_VR,T1))

                K_UR = Read_data("Choi_RSU","K_ur")

                v_j = Recover_Data(M_2,16,Hash(Concat_Data(TID_i,UID_j,K_UR,T2)))

                V_2_re = Hash(Concat_Data(TID_i,UID_j,V_1_re,v_j,K_UR,T2))

                if V_2_re==V_2:

                    print("V2 has been checked")

                else:

                    print("V2 has been NOT checked")

                    os._exit(1)

                r_k = Generate_Nonce()

                T3 = Generate_Timestamp()

                TID_i_new = Hash(Concat_Data(TID_i,u_i,T3))

                Store_data("Choi_RSU","TID_i",TID_i_new)

                M_3 = Xor_Data(Hash(Concat_Data(s_k,r_k)),Hash(Concat_Data(TID_i,UID_j,v_j,K_UR,T3)))

                M_4 = Xor_Data(u_i,Hash(Concat_Data(TID_i,UID_j,Hash(Concat_Data(s_k,r_k)),K_UR,T3)))

                M_5 = Xor_Data(CH_i,Hash(Concat_Data(TID_i,UID_j,u_i,K_VR,T3)))

                value = Hash(Concat_Data(s_k,r_k))

                M_6 = Xor_Data(value,Hash(Concat_Data(TID_i,UID_j,R_i,K_VR,T3)))

                M_7 = Xor_Data(v_j,Hash(Concat_Data(TID_i,UID_j,value,R_i,K_VR,T3)))

                V_3 = Hash(Concat_Data(TID_i,UID_j,v_j,value,K_UR,u_i,T3))

                V_4 = Hash(Concat_Data(TID_i_new,R_i,u_i,value,K_VR,v_j,T3))


                msg3 = Create_message({
                    "M_3": M_3,
                    "M_4": M_4,
                    "M_5": M_5,
                    "M_6": M_6,
                    "M_7": M_7,
                    "V_3": V_3,
                    "V_4": V_4,
                    "T3":T3
                })

                conn.sendall(msg3)

                print("Entity2: 已将消息发送给 Entity3。")

                seg_end = time.perf_counter()
                metrics["Entity2"] = _elapsed_ms(seg_start, seg_end)

        metrics["Entity2"] = round(metrics["Entity2"], 4)
        metrics["Entity2_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity2 protocol error: {e}"
        print(metrics["error"])


# =========================================
# 主协议入口
# =========================================
def Choi_protocol():
    metrics = _init_metrics()

    entity3_port = 9401   # Drone
    entity2_port = 9402   # RSU

    entity2_thread = threading.Thread(
        target=RSU_Entity,
        args=(entity2_port, metrics)
    )
    entity3_thread = threading.Thread(
        target=Drone_Entity,
        args=(entity3_port, '127.0.0.1', entity2_port, metrics)
    )
    entity1_thread = threading.Thread(
        target=Vehicle_Entity,
        args=('127.0.0.1', entity3_port, metrics)
    )

    entity2_thread.start()
    time.sleep(0.25)

    entity3_thread.start()
    time.sleep(0.25)

    entity1_thread.start()

    entity2_thread.join()
    entity3_thread.join()
    entity1_thread.join()

    metrics["Entity1"] = round(metrics["Entity1"], 4)
    metrics["Entity2"] = round(metrics["Entity2"], 4)
    metrics["Entity3"] = round(metrics["Entity3"], 4)

    metrics["total_time"] = round(
        metrics["Entity1"] + metrics["Entity2"] + metrics["Entity3"],
        4
    )

    if (
        metrics["Entity1_success"]
        and metrics["Entity2_success"]
        and metrics["Entity3_success"]
        and metrics["error"] is None
    ):
        metrics["success"] = True

    return metrics


if __name__ == "__main__":
    result = Choi_protocol()
    print("\n===== Protocol Timing Result =====")
    print(f"Entity1 Time : {result['Entity1']:.4f} ms")
    print(f"Entity2 Time : {result['Entity2']:.4f} ms")
    print(f"Entity3 Time : {result['Entity3']:.4f} ms")
    print(f"Total Time   : {result['total_time']:.4f} ms")
    print(f"Success      : {result['success']}")
    print(f"Error        : {result['error']}")