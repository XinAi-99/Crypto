import os
import statistics
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from typing import Dict, List, Any


from Miao_AKA import *
from Wang_AKA import *
from Choi_AKA import *
from Tanveer_modified import *
from Proposed_AKA import *

# =========================
# 1. 临时把 5 个协议都视为 Badshah_protocol
# =========================
PROTOCOLS = [
    {"name": "Tanveer et al.", "main": Tanveer_protocol},
    {"name": "Miao et al.", "main": Miao_protocol},
    {"name": "Choi et al.", "main": Choi_protocol},
    {"name": "Wang et al.", "main": Wang_protocol},
    {"name": "Proposed", "main": Proposed_Protocol}
]


# =========================
# 2. 单个协议跑一次
# =========================
def run_one_protocol_once(protocol_cfg: Dict[str, Any]) -> Dict[str, float]:
    """
    Badshah_protocol() 返回：
    {
        "Entity1": ... ms,
        "Entity2": ... ms,
        "Entity3": ... ms,
        "total_time": ... ms,
        "success": ...,
        "error": ...
    }
    """
    result = protocol_cfg["main"]()

    if not result["success"]:
        raise RuntimeError(f"{protocol_cfg['name']} failed: {result['error']}")

    return {
        "Entity1": round(result["Entity1"], 4),
        "Entity2": round(result["Entity2"], 4),
        "Entity3": round(result["Entity3"], 4),
        "total_time": round(result["total_time"], 4),
    }


# =========================
# 3. 单个协议跑 n 次
# =========================
def benchmark_one_protocol(protocol_cfg: Dict[str, Any], n_runs: int) -> Dict[str, Any]:
    entity1_times: List[float] = []
    entity2_times: List[float] = []
    entity3_times: List[float] = []
    total_times: List[float] = []

    for i in range(n_runs):
        result = run_one_protocol_once(protocol_cfg)

        entity1_times.append(result["Entity1"])
        entity2_times.append(result["Entity2"])
        entity3_times.append(result["Entity3"])
        total_times.append(result["total_time"])

        print(
            f"[{protocol_cfg['name']}] Run {i + 1}/{n_runs} | "
            f"Entity1={result['Entity1']:.4f} ms, "
            f"Entity2={result['Entity2']:.4f} ms, "
            f"Entity3={result['Entity3']:.4f} ms, "
            f"Total={result['total_time']:.4f} ms"
        )

    return {
        "name": protocol_cfg["name"],
        "Entity1_times": entity1_times,
        "Entity2_times": entity2_times,
        "Entity3_times": entity3_times,
        "total_times": total_times,
        "avg_Entity1": round(statistics.mean(entity1_times), 4),
        "avg_Entity2": round(statistics.mean(entity2_times), 4),
        "avg_Entity3": round(statistics.mean(entity3_times), 4),
        "avg_total_time": round(statistics.mean(total_times), 4),
    }


# =========================
# 4. 所有协议一起测试
# =========================
def benchmark_all_protocols(n_runs: int) -> List[Dict[str, Any]]:
    all_results = []

    for protocol_cfg in PROTOCOLS:
        print(f"\n===== Benchmarking {protocol_cfg['name']} =====")
        result = benchmark_one_protocol(protocol_cfg, n_runs)
        all_results.append(result)

    return all_results


# =========================
# 5. 输出平均值表格
# =========================
def build_average_table(all_results: List[Dict[str, Any]]) -> pd.DataFrame:
    rows = []
    for result in all_results:
        rows.append({
            "Protocol": result["name"],
            "Entity1 Avg Time (ms)": result["avg_Entity1"],
            "Entity2 Avg Time (ms)": result["avg_Entity2"],
            "Entity3 Avg Time (ms)": result["avg_Entity3"],
            "Total Avg Time (ms)": result["avg_total_time"],
        })

    return pd.DataFrame(rows)


# =========================
# 6. 画图：运行次数 vs 协议完整运行时间
# =========================
def plot_total_time_vs_runs(
    all_results: List[Dict[str, Any]],
    save_path: str = "Runtime.pdf"
):
    plt.rcParams["font.family"] = "Times New Roman"
    plt.rcParams["mathtext.fontset"] = "stix"
    plt.rcParams["axes.unicode_minus"] = False

    fig, ax = plt.subplots(figsize=(7.1, 4.8))

    for result in all_results:
        x = list(range(1, len(result["total_times"]) + 1))
        y = result["total_times"]
        ax.plot(
            x,
            y,
            marker="o",
            linewidth=1.6,
            markersize=4.5,
            label=result["name"]
        )

    ax.set_xlabel("Run Number", fontsize=10)
    ax.set_ylabel("Protocol Execution Time (ms)", fontsize=10)

    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))

    ax.tick_params(axis="both", which="major", labelsize=9, direction="in", length=4, width=0.8)
    ax.tick_params(axis="both", which="minor", direction="in", length=2, width=0.6)

    for spine in ax.spines.values():
        spine.set_linewidth(0.8)

    ax.legend(
        loc="upper left",
        fontsize=7,
        frameon=True,
        edgecolor="black",
        fancybox=False,
        framealpha=1.0
    )

    ax.grid(False)
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")

    plt.tight_layout()

    # 保存 PDF
    plt.savefig(save_path, format="pdf", bbox_inches="tight")
    print(f"Figure saved to {os.path.abspath(save_path)}")

    # 同时保存 PNG
    png_path = os.path.splitext(save_path)[0] + ".png"
    plt.savefig(png_path, dpi=600, bbox_inches="tight")
    print(f"Figure also saved to {os.path.abspath(png_path)}")

    plt.show()


# =========================
# 7. 保存每次运行详细结果
# =========================
def save_detailed_results(
    all_results: List[Dict[str, Any]],
    save_path: str = "protocol_detailed_results.csv"
):
    rows = []
    for result in all_results:
        n = len(result["total_times"])
        for i in range(n):
            rows.append({
                "Protocol": result["name"],
                "Run": i + 1,
                "Entity1 Time (ms)": result["Entity1_times"][i],
                "Entity2 Time (ms)": result["Entity2_times"][i],
                "Entity3 Time (ms)": result["Entity3_times"][i],
                "Total Time (ms)": result["total_times"][i],
            })

    df = pd.DataFrame(rows)
    df.to_csv(save_path, index=False, encoding="utf-8-sig")
    print(f"Detailed results saved to {os.path.abspath(save_path)}")


# =========================
# 8. 主函数
# =========================
def main():
    n_runs = 5

    print("Current working directory:", os.getcwd())

    all_results = benchmark_all_protocols(n_runs)

    avg_df = build_average_table(all_results)
    print("\n===== Average Execution Time Summary =====")
    print(avg_df.to_string(index=False))

    avg_csv_path = "protocol_average_results.csv"
    avg_df.to_csv(avg_csv_path, index=False, encoding="utf-8-sig")
    print(f"\nAverage results saved to {os.path.abspath(avg_csv_path)}")

    save_detailed_results(all_results, "protocol_detailed_results.csv")
    plot_total_time_vs_runs(all_results, "Runtime.pdf")


if __name__ == "__main__":
    main()