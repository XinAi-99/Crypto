from Standardized_Message import *
from Standardized_Cryptographic_Primitives import *

s = Generate_scalar()

ID_k = Generate_Nonce()

Store_data("Wang_CC","s",s)

Store_data("Wang_CC","ID_k",ID_k)

P= Get_base_point()

X_cck = ECC_Point_scalar_multiply(P,s)

ID_i = Generate_Nonce()

T_0 = Generate_Timestamp()

PID_i = Hash(Concat_Data(ID_i,s,T_0))

PID_k = Hash(Concat_Data(ID_k,s))

A_i = Hash(Concat_Data(ID_i,PID_i,PID_k,s))

Store_data("Wang_ECV","A_i",A_i)

Store_data("Wang_ECV","ID_i",ID_i)

Store_data("Wang_ECV","PID_i",PID_i)

Store_data("Wang_ECV","PID_k",PID_k)


CH_j = Generate_Nonce()

Res_j = Ideal_PUF(CH_j)

ID_j  = Generate_Nonce()

PID_j = Hash(Concat_Data(ID_j,Res_j))


Store_data("Wang_CC","CH_j",CH_j)

Store_data("Wang_CC","Res_j",Res_j)

Store_data("Wang_CC","PID_j",PID_j)

Store_data("Wang_UAV","ID_j",ID_j)

Store_data("Wang_UAV","PID_j",PID_j)

PID_kk = Xor_Data(PID_k,Res_j)

Store_data("Wang_UAV","PID_kk",PID_kk)

Store_data("Wang_UAV","CH_j",CH_j)

Store_data("Wang_UAV","Res_j",Res_j)


ID_l = Generate_Nonce()

T_1 = Generate_Timestamp()

PID_l = Hash(Concat_Data(ID_l,T_1))

A_l = Hash(Concat_Data(ID_l,PID_l,PID_k,s))

Bio = Generate_Nonce()

BK,HD = Gen(Bio)

n_l = Generate_Nonce()

PW_l = Generate_Nonce()

PID_ll = Xor_Data(PID_l,Hash(Concat_Data(PW_l,BK)))

PID_kk = Xor_Data(PID_k,Hash(Concat_Data(PID_l,BK)))

APW_l = Hash(Concat_Data(PW_l,ID_l,PID_ll,BK,n_l))

A_ll = Xor_Data(A_l,APW_l)

B_l = Hash(Concat_Data(A_l,APW_l,BK))

Store_data("Wang_User","ID_l",ID_l)

Store_data("Wang_User","PW_l",PW_l)

Store_data("Wang_User","Bio",Bio)

Store_data("Wang_User","PID_ll",PID_ll)

Store_data("Wang_User","PID_kk",PID_kk)

Store_data("Wang_User","A_ll",A_ll)

Store_data("Wang_User","B_l",B_l)

Store_data("Wang_User","HD",HD)

Store_data("Wang_User","n_l",n_l)

Store_data("Wang_CC","X_cck",X_cck)

Store_data("Wang_CC","PID_k",PID_k)

