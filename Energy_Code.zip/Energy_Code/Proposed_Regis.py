from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *

s = Generate_Nonce()

ID_s = Generate_Nonce()

Store_data("our_cs","s",s)

Store_data("our_cs","ID_s",ID_s)

ID_k = Generate_Nonce()

SP_k = Generate_Nonce()

HID_k = Hash(Concat_Data(ID_k,s))

A_k = Chebyshev_chaotic_map(SP_k,HID_k)

Store_data("our_cs","HID_k",HID_k)

Store_data("our_cs","A_k",A_k)

Store_data("our_drone","ID_k",ID_k)

Store_data("our_drone","HID_k",HID_k)

Store_data("our_drone","SP_k",SP_k)

ID_j = Generate_Nonce()

SP_j = Generate_Nonce()

HID_j = Hash(Concat_Data(ID_j,s))

A_j = Hash(Concat_Data(ID_s,s))

A_j_split = Split_Data(A_j,16,16)

K = Xor_Data(A_j_split[0],A_j_split[1])

B_j = Chebyshev_chaotic_map(K,HID_j)

C_j = Chebyshev_chaotic_map(SP_j,HID_j)

D_J = Xor_Data(Concat_Data(C_j,HID_k),Hash(Concat_Data(ID_j,s)))

E_j = Hash(Concat_Data(C_j,HID_k,ID_j,HID_j,s))

Store_data("our_cs","ID_j",ID_j)

Store_data("our_cs","HID_j",HID_j)

Store_data("our_cs","D_J",D_J)

Store_data("our_cs","E_j",E_j)

Bio_j = Generate_Nonce()

BK,HD = Gen(Bio_j)

PW_j = Generate_Nonce()

F_j = Hash(Concat_Data(ID_j,PW_j,BK))

G_j = Xor_Data(HD,Hash(Concat_Data(ID_j,PW_j)))

H_j = Xor_Data(Concat_Data(HID_j,SP_j,B_j,HID_k),F_j)

I_j = Hash(Concat_Data(ID_j,PW_j,BK,HID_j,SP_j,B_j,HID_k))

Store_data("our_user","ID_j",ID_j)
Store_data("our_user","PW_j",PW_j)
Store_data("our_user","Bio_j",Bio_j)
Store_data("our_user","G_j",G_j)
Store_data("our_user","H_j",H_j)
Store_data("our_user","I_j",I_j)
