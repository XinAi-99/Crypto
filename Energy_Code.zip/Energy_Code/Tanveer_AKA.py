from Standardized_Message import *
from Standardized_Cryptographic_Primitives import *
import threading
import socket
import os
import time


s_rc_file = "18_S_RC_database"
drone_file = "18_drone_database"
user_db = "18_user_database"

# 1. User
def User_Authentication(U_i_ip, U_i_port, S_ip, S_port):
    try:
        time.sleep(1)

        rp = Read_data(user_db, "rp")
        CT_r = Read_data(user_db, "CT_r")
        RN_r = Read_data(user_db, "RN_r")
        UI_UR = Read_data(user_db, "UI_UR")
        TC_UR = Read_data(user_db, "TC_UR")
        PIDk = Read_data(user_db, "PIDk")
        user_id = Read_data(user_db, "user_id")
        biometric_input = Read_data(user_db, "biometric")
        password_input = Read_data(user_db, "password")

        AD_r_stored = Read_data(user_db, "AD_r")
        IV_r_stored = Read_data(user_db, "IV_r")
        k_r_stored = Read_data(user_db, "k_r")

        Bmk_UR = Rep(biometric_input, rp)

        D_bytes = Concat_Data(Hash(Concat_Data(Bmk_UR, password_input)), RN_r)
        D1_bytes = D_bytes[:16]
        D2_bytes = D_bytes[16:32]

        k_l_bytes = Xor_Data(D1_bytes, D2_bytes)
        k_l_bytes = k_l_bytes[:16]

        E_bytes = Concat_Data(Hash(user_id), RN_r)
        E1_bytes = E_bytes[:16]
        E2_bytes = E_bytes[16:32]

        AD_l_bytes = Xor_Data(E1_bytes, E2_bytes)
        AD_l_bytes = AD_l_bytes[:16]

        IV_l_bytes = RN_r[:16]

        PT_r_bytes = AEGIS128_Decrypt(CT_r, AD_l_bytes, IV_l_bytes, k_l_bytes)

        PT_UI = PT_r_bytes[:16]
        PT_TC = PT_r_bytes[16:32]
        PT_PID = PT_r_bytes[32:48]

        if PT_UI != UI_UR or PT_TC != TC_UR or PT_PID != PIDk:
            print("[User] PT_r verification failed")
            os._exit(1)

        T_ul = int(time.time()).to_bytes(4, "big")
        RN_ul = Generate_Nonce()
        Sku = Generate_scalar()

        G_bytes = Read_data(s_rc_file, "G")
        Puuk = ECC_Point_scalar_multiply(G_bytes, Sku)

        Pusk = Read_data(s_rc_file, "Pusk")
        K_ul = ECC_Point_scalar_multiply(Pusk, Sku)

        G_ul = Hash(Concat_Data(T_ul, K_ul))

        UI_PID = Concat_Data(UI_UR, PIDk)
        G_ul2 = Xor_Data(UI_PID, G_ul)

        G_ul2_mid = len(G_ul2) // 2
        G_ul2_1 = G_ul2[:G_ul2_mid]
        G_ul2_2 = G_ul2[G_ul2_mid:]

        AD_ul = Xor_Data(G_ul2_1, G_ul2_2)
        AD_ul = AD_ul[:16]

        IV_ul = G_ul[:16]

        CT_ul = AEGIS128_Encrypt(RN_ul, AD_ul, IV_ul, TC_UR)

        dict1 = {
            "T_ul": T_ul,
            "G_ul2": G_ul2,
            "CT_ul": CT_ul,
            "Puuk": Puuk
        }

        Msg1 = Create_message(dict1)

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as user_socket:
            user_socket.connect((S_ip, S_port))

            print("User sends Msg1 to Server")

            user_socket.sendall(Msg1)

            Msg3 = Parse_Message(user_socket.recv(4096))

            print(f"User has received {Msg3}")

            T_d3 = Msg3.get("T_d3")
            CT_d3 = Msg3.get("CT_d3")
            Pudk = Msg3.get("Pudk")

            Suk = ECC_Point_scalar_multiply(Pudk, Sku)

            X_ur = Hash(Concat_Data(K_ul, RN_ul, TC_UR))
            Q_d3 = Hash(Concat_Data(Suk, X_ur, T_d3, Pudk))

            K_6 = Q_d3[:16]

            X_d3 = AEGIS128_Decrypt(CT_d3, b'', K_6, K_6)

            SK_u = Hash(Concat_Data(Suk, X_ur, T_d3, Pudk, X_d3))

            print(f"[User] final session key SK_u is {SK_u.hex()}")
            print("User authentication flow completed successfully")

    except Exception as e:
        print(f"User protocol error: {e}")
        os._exit(1)


# 2. Server
def Server_Authentication(S_ip, S_port, Dk_ip, Dk_port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
            server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_socket.bind((S_ip, S_port))
            server_socket.listen(1)

            print("Server waiting for User connection")

            user_conn, _ = server_socket.accept()

            with user_conn:
                Msg1 = Parse_Message(user_conn.recv(4096))

                print(f"Server has received {Msg1}")

                T_ul = Msg1.get("T_ul")
                G_ul2 = Msg1.get("G_ul2")
                CT_ul = Msg1.get("CT_ul")
                Puuk = Msg1.get("Puuk")

                Sks = Read_data(s_rc_file, "Sks")
                K_sl = ECC_Point_scalar_multiply(Puuk, Sks)

                G_sl = Hash(Concat_Data(T_ul, K_sl))
                UI_PID = Xor_Data(G_ul2, G_sl)

                UI_UR = UI_PID[:16]
                PIDk = UI_PID[16:]

                stored_UI = Read_data(s_rc_file, "UI_UR")

                if UI_UR != stored_UI:
                    print("[Server] UI_UR verification failed")
                    os._exit(1)

                print("[Server] user verified successfully")

                CT_s = Read_data(s_rc_file, "CT_s")
                RN_a = Read_data(s_rc_file, "RN_a")

                AA = Concat_Data(Sks, RN_a)
                IV_sl = RN_a[:16]

                AA1 = AA[:16]
                AA2 = AA[16:32]

                k_sl = Xor_Data(AA1, AA2)
                k_sl = k_sl[:16]

                AD_s = UI_UR
                PT_s = AEGIS128_Decrypt(CT_s, AD_s, IV_sl, k_sl)

                TC_UR = PT_s[:16]
                PIDk_stored = PT_s[16:32]
                TS_Dk = PT_s[32:48]

                G_ul2_mid = len(G_ul2) // 2
                G_ul2_1 = G_ul2[:G_ul2_mid]
                G_ul2_2 = G_ul2[G_ul2_mid:]

                AD_ul = Xor_Data(G_ul2_1, G_ul2_2)
                AD_ul = AD_ul[:16]
                IV_ul = G_sl[:16]

                RN_ul = AEGIS128_Decrypt(CT_ul, AD_ul, IV_ul, TC_UR)

                print("[Server] user message decrypted successfully")

                T_s2 = int(time.time()).to_bytes(4, "big")
                RN_sl = Generate_Nonce()
                RN_s2 = Generate_Nonce()[:8]

                X_sl = Hash(Concat_Data(K_sl, RN_ul, TC_UR))

                AD_s2 = Concat_Data(T_s2, RN_s2, T_s2)
                IV_s3 = Xor_Data(PIDk, AD_s2)
                IV_s3 = IV_s3[:16]

                PT_sl = Concat_Data(X_sl, RN_sl)

                CT_s2 = AEGIS128_Encrypt(PT_sl, AD_s2, IV_s3, TS_Dk)

                dict2 = {
                    "T_s2": T_s2,
                    "CT_s2": CT_s2,
                    "RN_s2": RN_s2,
                    "Puuk": Puuk
                }

                Msg2 = Create_message(dict2)

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_to_drone_socket:
                    server_to_drone_socket.connect((Dk_ip, Dk_port))

                    print("Server sends Msg2 to Drone")

                    server_to_drone_socket.sendall(Msg2)

                    Msg3 = server_to_drone_socket.recv(4096)

                    if not Msg3:
                        print("[Server] no response from drone")
                        os._exit(1)

                    print("Server receives response from Drone")

                user_conn.sendall(Msg3)

                print("Server forwards Msg3 to User")
                print("Server authentication flow completed successfully")

    except Exception as e:
        print(f"Server protocol error: {e}")
        os._exit(1)


# 3. Drone
def Drone_Authentication(Dk_ip, Dk_port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as drone_socket:
            drone_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            drone_socket.bind((Dk_ip, Dk_port))
            drone_socket.listen(1)

            print("Drone waiting for Server connection")

            server_conn, _ = drone_socket.accept()

            with server_conn:
                Msg2 = Parse_Message(server_conn.recv(4096))

                print(f"Drone has received {Msg2}")

                T_s2 = Msg2.get("T_s2")
                CT_s2 = Msg2.get("CT_s2")
                RN_s2 = Msg2.get("RN_s2")
                Puuk = Msg2.get("Puuk")

                PIDk = Read_data(drone_file, "PIDk")
                TS_Dk = Read_data(drone_file, "TS_Dk")

                AD_d1 = Concat_Data(T_s2, RN_s2, T_s2)
                IV_d1 = Xor_Data(PIDk, AD_d1)
                IV_d1 = IV_d1[:16]

                PT_s1 = AEGIS128_Decrypt(CT_s2, AD_d1, IV_d1, TS_Dk)

                X_sl = PT_s1[:32]
                RN_sl = PT_s1[32:48]

                T_d3 = int(time.time()).to_bytes(4, "big")
                RN_d3 = Generate_Nonce()
                Skd = Generate_scalar()

                G_bytes = Read_data(s_rc_file, "G")
                Pudk = ECC_Point_scalar_multiply(G_bytes, Skd)

                Suk = ECC_Point_scalar_multiply(Puuk, Skd)

                Q_d3 = Hash(Concat_Data(Suk, X_sl, T_d3, Pudk))
                K_5 = Q_d3[:16]

                RN_combined = Xor_Data(RN_d3, RN_sl)
                TS_T = Concat_Data(TS_Dk, T_s2)

                X_d3 = Hash(Concat_Data(RN_combined, TS_T))
                CT_d3 = AEGIS128_Encrypt(X_d3, b'', K_5, K_5)

                SK_d = Hash(Concat_Data(Suk, X_sl, T_d3, Pudk, X_d3))

                print(f"[Drone] final session key SK_d is {SK_d.hex()}")

                dict3 = {
                    "T_d3": T_d3,
                    "CT_d3": CT_d3,
                    "Pudk": Pudk
                }

                Msg3 = Create_message(dict3)

                server_conn.sendall(Msg3)

                print("Drone authentication flow completed successfully")

    except Exception as e:
        print(f"Drone protocol error: {e}")
        os._exit(1)


def Tanveer_Protocol():
    U_i_ip = "127.0.50.1"
    U_i_port = 13502

    S_ip = "127.0.50.1"
    S_port = 13503

    Dk_ip = "127.0.50.1"
    Dk_port = 13504

    drone_thread = threading.Thread(
        target=Drone_Authentication,
        args=(Dk_ip, Dk_port)
    )

    server_thread = threading.Thread(
        target=Server_Authentication,
        args=(S_ip, S_port, Dk_ip, Dk_port)
    )

    user_thread = threading.Thread(
        target=User_Authentication,
        args=(U_i_ip, U_i_port, S_ip, S_port)
    )

    drone_thread.start()
    time.sleep(0.25)

    server_thread.start()
    time.sleep(0.25)

    user_thread.start()

    drone_thread.join()
    server_thread.join()
    user_thread.join()

Tanveer_Protocol()
