from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *


def Registration_Phase():
    print("=== 开始 Miao 协议注册阶段 ===")

    # 1. 系统初始化 (TA) [cite: 569]
    s = Generate_scalar()  # TA 的秘密私钥 s
    P = Get_base_point()  # ECC 基点 P
    S_pub = ECC_Point_scalar_multiply(P,s)  # TA 公钥 S = sP

    Store_data("Miao_TA_Storage", "s", s)
    Store_data("Miao_System_Params", "S_pub", S_pub)

    # 2. RSU 注册 [cite: 131, 132]
    RID_j = Generate_Nonce()
    h = Generate_Nonce()  # TA 随机选取的 h
    # a_j = H(s || RID_j || h)
    a_j = Hash(Concat_Data(s, RID_j, h))

    Store_data("Miao_RSU_Storage", "RID_j", RID_j)
    Store_data("Miao_RSU_Storage", "a_j", a_j)
    Store_data("Miao_RSU_Storage", "h", h)

    # 3. 车辆 (Vehicle) 注册 [cite: 133, 134, 135]
    VID_i = Generate_Nonce()
    b_i = Generate_scalar()
    c_i = Generate_Nonce()
    B_i = ECC_Point_scalar_multiply(P,b_i)  # B_i = b_i * P

    # VD_i = H(VID_i || s)
    VD_i = Hash(Concat_Data(VID_i, s))
    # VF_i = H(VD_i || h)
    VF_i = Hash(Concat_Data(VD_i, h))
    # TID_i = E_H(h) (VD_i ^ c_i) -> 使用 ASCON 加密
    encryption_key = Hash(h)[:16]
    TID_i = AES_Enc(Xor_Data(VD_i, c_i),encryption_key)

    # 存储到车辆
    Store_data("Miao_Vehicle_Storage", "VID_i", VID_i)
    Store_data("Miao_Vehicle_Storage", "TID_i", TID_i)
    Store_data("Miao_Vehicle_Storage", "VD_i", VD_i)
    Store_data("Miao_Vehicle_Storage", "VF_i", VF_i)
    Store_data("Miao_Vehicle_Storage", "b_i", b_i)

    # TA 也会把凭证发给 RSU
    Store_data("Miao_RSU_Storage", "TID_i", TID_i)
    Store_data("Miao_RSU_Storage", "c_i", c_i)
    Store_data("Miao_RSU_Storage", "B_i", B_i)

    # 4. 无人机 (UAV) 注册 [cite: 136, 137, 138]
    UID_k = Generate_Nonce()
    # VE_k = H(UID_k || a_j)
    VE_k = Hash(Concat_Data(UID_k, a_j))

    Store_data("Miao_UAV_Storage", "UID_k", UID_k)
    Store_data("Miao_UAV_Storage", "VE_k", VE_k)

    print("=== 注册阶段完成，数据已存储 ===")


if __name__ == "__main__":
    Registration_Phase()