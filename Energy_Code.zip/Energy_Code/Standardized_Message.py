import os
import base64
from typing import Optional
import struct
from typing import Dict

def Read_data(file_name: str, data_name: str) -> Optional[bytes]:
    """
    Read the value corresponding to data_name from a txt file.
    Values are stored as Base64-encoded bytes.
    Returns bytes, or None if not found / error.
    """
    try:
        if not os.path.exists(file_name):
            print(f"File '{file_name}' does not exist")
            return None

        with open(file_name, "r", encoding="utf-8") as f:
            data_lines = f.readlines()

        params = {}
        current_name = None
        current_value = []

        for line in data_lines:
            line = line.rstrip("\n")

            if ":" in line:
                if current_name is not None:
                    params[current_name] = "\n".join(current_value).strip()

                current_name, value = line.split(":", 1)
                current_name = current_name.strip()
                current_value = [value.strip()]
            else:
                current_value.append(line.strip())

        if current_name is not None:
            params[current_name] = "\n".join(current_value).strip()

        if data_name not in params:
            print(f"Data '{data_name}' not found")
            return None

        # Base64 → bytes (remove any line breaks just in case)
        b64_text = params[data_name].replace("\n", "").strip()
        return base64.b64decode(b64_text)

    except Exception as e:
        print(f"Error reading data: {e}")
        return None


def Store_data(file_name: str, data_name: str, data_value: bytes) -> None:
    """
    Store bytes data into a txt file using Base64 encoding.
    If data_name exists, update it; otherwise append new entry.
    """
    try:
        if not isinstance(data_value, (bytes, bytearray)):
            raise TypeError("data_value must be bytes-like")

        b64_value = base64.b64encode(bytes(data_value)).decode("utf-8")

        if not os.path.exists(file_name):
            with open(file_name, "w", encoding="utf-8"):
                pass

        with open(file_name, "r", encoding="utf-8") as f:
            data_lines = f.readlines()

        data_found = False
        new_lines = []
        i = 0

        while i < len(data_lines):
            line = data_lines[i].rstrip("\n")

            if line.startswith(f"{data_name}:"):
                # overwrite this entry (single-line storage)
                new_lines.append(f"{data_name}:{b64_value}\n")
                data_found = True

                # skip possible multi-line old value (lines without ':')
                i += 1
                while i < len(data_lines) and ":" not in data_lines[i]:
                    i += 1
                continue

            new_lines.append(data_lines[i])
            i += 1

        if not data_found:
            new_lines.append(f"{data_name}:{b64_value}\n")

        with open(file_name, "w", encoding="utf-8") as f:
            f.writelines(new_lines)

        print(f"Data '{data_name}' successfully stored")

    except Exception as e:
        print(f"Error storing data: {e}")

def Parse_Message(message: bytes) -> Dict[str, bytes]:
    """
    Parse a binary message and extract each data block.

    Message format (TLV-like):
        - name_length : 2 bytes (uint16, big-endian)
        - name        : name_length bytes (UTF-8)
        - data_length : 4 bytes (uint32, big-endian)
        - data        : data_length bytes

    Returns:
        dict[str, bytes]: mapping from name to raw bytes data.
    """
    if not isinstance(message, bytes):
        raise TypeError("message must be bytes")

    data_dict = {}
    i = 0
    msg_len = len(message)

    while i < msg_len:
        if i + 2 > msg_len:
            raise ValueError("truncated message (name_length)")

        name_length = struct.unpack("!H", message[i:i + 2])[0]
        i += 2

        if i + name_length > msg_len:
            raise ValueError("truncated message (name)")

        name = message[i:i + name_length].decode("utf-8")
        i += name_length

        if i + 4 > msg_len:
            raise ValueError("truncated message (data_length)")

        data_length = struct.unpack("!I", message[i:i + 4])[0]
        i += 4

        if i + data_length > msg_len:
            raise ValueError("truncated message (data)")

        data = message[i:i + data_length]
        i += data_length

        # Store raw bytes directly
        data_dict[name] = data

    return data_dict

def Create_message(data_dict: Dict[str, bytes]) -> bytes:
    """
    Construct a binary message from multiple data blocks.

    Input:
        data_dict : dict[str, bytes]

    Output:
        bytes : encoded binary message
    """
    if not isinstance(data_dict, dict):
        raise TypeError("data_dict must be a dict")

    message = bytearray()

    for name, data in data_dict.items():
        if not isinstance(name, str):
            raise TypeError("data_dict keys must be str")
        if not isinstance(data, bytes):
            raise TypeError(f"data for '{name}' must be bytes")

        name_bytes = name.encode("utf-8")
        name_length = len(name_bytes)
        data_length = len(data)

        # Pack: name_length || name || data_length || data
        message += struct.pack("!H", name_length)
        message += name_bytes
        message += struct.pack("!I", data_length)
        message += data

    return bytes(message)
