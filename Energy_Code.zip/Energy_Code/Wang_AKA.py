import threading
import socket
import time
from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *


def _init_metrics():
    return {
        "Entity1": 0.0,         # ms   -> ECV
        "Entity2": 0.0,         # ms   -> CC
        "Entity3": 0.0,         # ms   -> UAV
        "total_time": None,     # ms
        "success": False,
        "error": None,
        "Entity1_success": False,
        "Entity2_success": False,
        "Entity3_success": False,
    }


def _elapsed_ms(start_time, end_time):
    return round((end_time - start_time) * 1000, 4)


# =========================================
# Entity1（ECV）
# 消息流：
# 1) Entity1 -> Entity2 : r1
# 4) Entity2 -> Entity1 : r4
# =========================================
def ECV_Entity(cc_ip, cc_port, metrics):
    try:

        ID_l = Read_data("Wang_User","ID_l")

        PW_l = Read_data("Wang_User","PW_l")

        Bio = Read_data("Wang_User","Bio")

        n_l = Read_data("Wang_User","n_l")

        HD = Read_data("Wang_User","HD")

        PID_ll = Read_data("Wang_User","PID_ll")

        A_ll = Read_data("Wang_User","A_ll")

        BK = Rep(Bio,HD)

        PID_l = Xor_Data(PID_ll,Hash(Concat_Data(PW_l,BK)))

        APW_l_recomputed = Hash(Concat_Data(PW_l,ID_l,PID_ll,BK,n_l))

        A_l_recomputed = Xor_Data(A_ll,APW_l_recomputed)

        B_l_recomputed = Hash(Concat_Data(A_l_recomputed,APW_l_recomputed,BK))

        B_l_read = Read_data("Wang_User","B_l")

        if B_l_recomputed == B_l_read:

            print("User login successfully")

        else:

            print("User login failed")

            os._exit(1)


        # =========================
        # 第一段：生成随机值 r1 并发送给 Entity2
        # =========================
        seg1_start = time.perf_counter()

        y_l = Generate_scalar()

        P = Get_base_point()

        Y_1 = ECC_Point_scalar_multiply(P,y_l)

        X_cck = Read_data("Wang_CC","X_cck")

        Y_2 = ECC_Point_scalar_multiply(X_cck,y_l)

        T_2 = Generate_Timestamp()

        PID_kk = Read_data("Wang_User","PID_kk")

        PID_k = Xor_Data(PID_kk,Hash(Concat_Data(PID_l,BK)))

        M_1 = Xor_Data(PID_l,Hash(Concat_Data(PID_k,T_2,Y_1,Y_2)))

        PID_j  =Read_data("Wang_UAV","PID_j")

        M_2 = Hash(Concat_Data(PID_l,PID_k,PID_j,Y_1,Y_2))

        M_3 = Xor_Data(PID_j,Hash(Concat_Data(PID_k,Y_2,T_2)))

        msg1 = Create_message({
            "M_1": M_1,
            "M_2": M_2,
            "M_3": M_3,
            "Y_1": Y_1,
            "T_2": T_2
        })

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((cc_ip, cc_port))
            s.sendall(msg1)

            seg1_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg1_start, seg1_end)

            # 等待最终响应（不计时）
            resp_data = s.recv(2048)
            msg4 = Parse_Message(resp_data)

            # =========================
            # 第二段：接收并处理最终消息
            # =========================
            seg2_start = time.perf_counter()

            M_9 = msg4.get("M_9")

            Y_3 = msg4.get("Y_3")

            print("Entity1: 已收到来自 Entity2 的最终消息。")

            PID_i = Read_data("Wang_ECV","PID_i")

            M_99 = Hash(Concat_Data(Y_3,Y_1,Y_2,PID_i,PID_k,PID_j))

            if M_9 == M_99:

                print("M_9 has been authenticated")

            else:

                print("M_9 has been not authenticated")

                os._exit(1)

            Y_4 = ECC_Point_scalar_multiply(Y_3,y_l)

            SK_ij = Hash(Concat_Data(PID_i,PID_j,Y_1,Y_4))

            SK_ik = Hash(Concat_Data(PID_i,PID_k,Y_1,Y_2))

            print(f"SK_ij computed by user is {SK_ij}")

            print(f"SK_ik computed by user is {SK_ik}")

            seg2_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity1"] = round(metrics["Entity1"], 4)
        metrics["Entity1_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity1 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity2（CC）
# 消息流：
# 1) 接收 Entity1 的 r1
# 2) Entity2 -> Entity3 : r2
# 3) 接收 Entity3 的 r3
# 4) Entity2 -> Entity1 : r4
# =========================================
def CC_Entity(listen_port, uav_ip, uav_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg1（不计时）
                data = conn.recv(2048)

                # =========================
                # 第一段：处理 Msg1 并发送 Msg2 给 Entity3
                # =========================
                seg1_start = time.perf_counter()

                msg1 = Parse_Message(data)

                print("Entity2: 已收到来自 Entity1 的消息。")

                M_1 = msg1.get("M_1")

                M_2 = msg1.get("M_2")

                M_3 = msg1.get("M_3")

                Y_1 = msg1.get("Y_1")

                T_2 = msg1.get("T_2")

                s = Read_data("Wang_CC","s")

                # P = Get_base_point()

                Y_2 = ECC_Point_scalar_multiply(Y_1,s)

                PID_k = Read_data("Wang_CC","PID_k")

                PID_l_rcv =  Xor_Data(M_1,Hash(Concat_Data(PID_k,T_2,Y_1,Y_2)))

                PID_j_rcv = Xor_Data(M_3,Hash(Concat_Data(PID_k,Y_2,T_2)))

                M_2_recomputed = Hash(Concat_Data(PID_l_rcv,PID_k,PID_j_rcv,Y_1,Y_2))

                if M_2_recomputed == M_2:

                    print("M_2 has been authenticated")

                else:

                    print("M_2 has been not authenticated")

                    os._exit(1)

                r_1 = Generate_Nonce()

                PID_i = Read_data("Wang_ECV","PID_i")

                T_3 = Generate_Timestamp()

                M_4 = Xor_Data(PID_i,Hash(Concat_Data(PID_k,PID_j_rcv,T_3)))

                M_5 = Xor_Data(r_1,Hash(Concat_Data(PID_i,PID_k,PID_j_rcv,T_3)))

                M_6 = Hash(Concat_Data(r_1,PID_i,PID_k,PID_j_rcv,T_3))

                msg2 = Create_message({
                    "M_4":M_4,
                    "M_5":M_5,
                    "M_6":M_6,
                    "Y_1":Y_1,
                    "T_3":T_3
                })

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as uav_sock:
                    uav_sock.connect((uav_ip, uav_port))
                    uav_sock.sendall(msg2)

                    seg1_end = time.perf_counter()
                    metrics["Entity2"] += _elapsed_ms(seg1_start, seg1_end)

                    # 等待 Entity3 响应（不计时）
                    uav_resp = uav_sock.recv(2048)

                    msg3 = Parse_Message(uav_resp)

                    # =========================
                    # 第二段：处理 Msg3 并向 Entity1 返回最终消息
                    # =========================
                    seg2_start = time.perf_counter()

                    print(f"Entity2: 已收到来自 Entity3 的消息 {msg3}。")

                    M_7 = msg3.get("M_7")

                    M_8 = msg3.get("M_8")

                    Y_3 = msg3.get("Y_3")

                    CH_j = Read_data("Wang_CC","CH_j")

                    Data =  Xor_Data(M_7,Hash(Concat_Data(r_1,Y_3,CH_j)))

                    Data_split = Split_Data(Data,16,16)

                    Res_j_new = Data_split[0]

                    r_2 = Data_split[1]

                    CH_j_update = Hash(Concat_Data(CH_j,r_1,r_2))

                    CH_j_update_split = Split_Data(CH_j_update,16,16)

                    CH_j_new = Xor_Data(CH_j_update_split[0],CH_j_update_split[1])

                    M_8_re = Hash(Concat_Data(r_1,r_2,Y_3,Res_j_new,CH_j,CH_j_new,PID_k,PID_j_rcv))

                    if M_8_re == M_8:

                        print("M_8 has been authenticated")

                    else:

                        print("M_8 has been not authenticated")

                        os._exit(1)

                    M_9 = Hash(Concat_Data(Y_3,Y_1,Y_2,PID_i,PID_k,PID_j_rcv))

                    SK_kj = Hash(Concat_Data(r_1,r_2,PID_k,PID_j_rcv,CH_j))

                    SK_ki = Hash(Concat_Data(PID_i,PID_k,Y_1,Y_2))

                    print(f"SK_kj computed by CC is {SK_kj}")

                    print(f"SK_ki computed by CC is {SK_ki}")

                    # Store_data("Wang_CC","CH_j",CH_j_new)

                    # Store_data("Wang_CC","Res_j",Res_j_new)

                    ID_j = Read_data("Wang_UAV","ID_j")

                    PID_j_new = Hash(Concat_Data(ID_j,Res_j_new))

                    # Store_data("Wang_CC","PID_j","PID_j_new")

                    msg4 = Create_message({
                       "M_9":M_9,
                        "Y_3":Y_3
                    })

                    conn.sendall(msg4)

                    print("Entity2: 已将最终消息发送给 Entity1。")

                    seg2_end = time.perf_counter()
                    metrics["Entity2"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity2"] = round(metrics["Entity2"], 4)
        metrics["Entity2_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity2 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity3（UAV）
# 消息流：
# 2) 接收 Entity2 的 r2
# 3) Entity3 -> Entity2 : r3
# =========================================
def UAV_Entity(listen_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg2（不计时）
                data = conn.recv(2048)

                # =========================
                # 收到 Msg2 后开始计时：处理 + 发送 Msg3
                # =========================
                seg_start = time.perf_counter()

                msg2 = Parse_Message(data)

                print("Entity3: 已收到来自 Entity2 的消息。")

                M_4 = msg2.get("M_4")

                M_5 = msg2.get("M_5")

                M_6 = msg2.get("M_6")

                Y_1 = msg2.get("Y_1")

                T_3 = msg2.get("T_3")

                PID_kk = Read_data("Wang_UAV","PID_kk")

                Res_j = Read_data("Wang_UAV","Res_j")

                PID_j = Read_data("Wang_UAV","PID_j")

                PID_k_recover = Xor_Data(PID_kk,Res_j)

                PID_i_rcv = Xor_Data(M_4,Hash(Concat_Data(PID_k_recover,PID_j,T_3)))

                r_1 = Recover_Data(M_5,16,Hash(Concat_Data(PID_i_rcv,PID_k_recover,PID_j,T_3)))

                M_6_re = Hash(Concat_Data(r_1,PID_i_rcv,PID_k_recover,PID_j,T_3))

                if M_6_re == M_6:

                    print("M_6 has been authenticated")

                else:

                    print("M_6 has been not authenticated")

                    os._exit(1)

                r_2 = Generate_Nonce()

                CH_j = Read_data("Wang_UAV","CH_j")

                SK_jk = Hash(Concat_Data(r_1,r_2,PID_k_recover,PID_j,CH_j))

                y_2 = Generate_scalar()

                P = Get_base_point()

                Y_3 = ECC_Point_scalar_multiply(P,y_2)

                Y_4 = ECC_Point_scalar_multiply(Y_1,y_2)

                SK_ij = Hash(Concat_Data(PID_i_rcv,PID_j,Y_1,Y_4))

                print(f"SK_jk computed by UAV is {SK_jk}")

                print(f"SK_ij computed by UAV is {SK_ij}")

                CH_j_update = Hash(Concat_Data(CH_j,r_1,r_2))

                CH_j_update_split = Split_Data(CH_j_update,16,16)

                CH_j_new = Xor_Data(CH_j_update_split[0],CH_j_update_split[1])

                Res_j_new = Ideal_PUF(CH_j_new)

                ID_j = Read_data("Wang_UAV","ID_j")

                PID_j_new = Hash(Concat_Data(ID_j,Res_j_new))


                M_7 = Xor_Data(Hash(Concat_Data(r_1,Y_3,CH_j)),Concat_Data(Res_j_new,r_2))

                M_8 = Hash(Concat_Data(r_1,r_2,Y_3,Res_j_new,CH_j,CH_j_new,PID_k_recover,PID_j))



                msg3 = Create_message({
                  "M_7":M_7,
                    "M_8":M_8,
                    "Y_3":Y_3
                })

                conn.sendall(msg3)

                print("Entity3: 已将消息发送给 Entity2。")

                seg_end = time.perf_counter()

                metrics["Entity3"] = _elapsed_ms(seg_start, seg_end)

        metrics["Entity3"] = round(metrics["Entity3"], 4)
        metrics["Entity3_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity3 protocol error: {e}"
        print(metrics["error"])


# =========================================
# 主协议入口
# =========================================
def Wang_protocol():
    metrics = _init_metrics()

    entity2_port = 4001
    entity3_port = 4002

    entity2_thread = threading.Thread(
        target=CC_Entity,
        args=(entity2_port, '127.0.0.1', entity3_port, metrics)
    )
    entity3_thread = threading.Thread(
        target=UAV_Entity,
        args=(entity3_port, metrics)
    )
    entity1_thread = threading.Thread(
        target=ECV_Entity,
        args=('127.0.0.1', entity2_port, metrics)
    )

    entity2_thread.start()
    time.sleep(0.25)

    entity3_thread.start()
    time.sleep(0.25)

    entity1_thread.start()

    entity2_thread.join()
    entity3_thread.join()
    entity1_thread.join()

    metrics["Entity1"] = round(metrics["Entity1"], 4)
    metrics["Entity2"] = round(metrics["Entity2"], 4)
    metrics["Entity3"] = round(metrics["Entity3"], 4)

    metrics["total_time"] = round(
        metrics["Entity1"] + metrics["Entity2"] + metrics["Entity3"],
        4
    )

    if (
        metrics["Entity1_success"]
        and metrics["Entity2_success"]
        and metrics["Entity3_success"]
        and metrics["error"] is None
    ):
        metrics["success"] = True

    return metrics


if __name__ == "__main__":
    result = Wang_protocol()
    print("\n===== Wang Protocol Timing Result =====")
    print(f"Entity1 Time : {result['Entity1']:.4f} ms")
    print(f"Entity2 Time : {result['Entity2']:.4f} ms")
    print(f"Entity3 Time : {result['Entity3']:.4f} ms")
    print(f"Total Time   : {result['total_time']:.4f} ms")
    print(f"Success      : {result['success']}")
    print(f"Error        : {result['error']}")