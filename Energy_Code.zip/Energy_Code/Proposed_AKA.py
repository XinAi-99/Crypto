import threading
import socket
import time
from Standardized_Cryptographic_Primitives import *
from Standardized_Message import *


def _init_metrics():
    return {
        "Entity1": 0.0,         # ms   -> User
        "Entity2": 0.0,         # ms   -> Control Center
        "Entity3": 0.0,         # ms   -> UAV
        "total_time": None,     # ms
        "success": False,
        "error": None,
        "Entity1_success": False,
        "Entity2_success": False,
        "Entity3_success": False,
    }


def _elapsed_ms(start_time, end_time):
    return round((end_time - start_time) * 1000, 4)


# =========================================
# Entity1（User）
# 消息流：
# 1) Entity1 -> Entity2 : r1
# 3) Entity3 -> Entity1 : r3
# =========================================
def User_Entity(cc_ip, cc_port, listen_ip, listen_port, metrics):
    try:

        ID_j = Read_data("our_user","ID_j")

        PW_j = Read_data("our_user","PW_j")

        Bio_j = Read_data("our_user","Bio_j")

        G_j = Read_data("our_user","G_j")

        H_j = Read_data("our_user","H_j")

        I_j = Read_data("our_user","I_j")

        HD = Recover_Data(G_j,18,Hash(Concat_Data(ID_j,PW_j)))

        BK = Rep(Bio_j,HD)

        M_1 = Hash(Concat_Data(ID_j,PW_j,BK))

        Data = Xor_Data(H_j,M_1)

        Data_split = Split_Data(Data,32,16,32,32)

        HID_j = Data_split[0]

        SP_j = Data_split[1]

        B_j = Data_split[2]

        HID_k = Data_split[3]

        I_jj = Hash(Concat_Data(ID_j,PW_j,BK,HID_j,SP_j,B_j,HID_k))

        if I_j==I_jj:

            print("user login successfully")

        else:

            print("user login failed")

            os._exit(1)


        # =========================
        # 第一段：生成随机值 r1 并发送给 Entity2
        # =========================
        seg1_start = time.perf_counter()

        n1 =Generate_Nonce()

        n2 = Generate_Nonce()

        T1 = Generate_Timestamp()


        M_2 = Chebyshev_chaotic_map(n1,HID_j)

        M_3 = Chebyshev_chaotic_map(n1,B_j)

        M_4 =Xor_Data(HID_j,M_3)

        M_5 = Xor_Data(Concat_Data(HID_k,n2),Hash(Concat_Data(HID_j,M_3,T1)))

        M_6 = Hash(Concat_Data(ID_j,HID_j,HID_k,M_3,n2,T1))

        msg1 = Create_message({
            "M_2":M_2,
            "M_4":M_4,
            "M_5":M_5,
            "M_6":M_6,
            "T1":T1
        })

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((cc_ip, cc_port))
            s.sendall(msg1)

            print("Entity1: 已将消息发送给 Entity2。")

            seg1_end = time.perf_counter()
            metrics["Entity1"] += _elapsed_ms(seg1_start, seg1_end)

        # =========================
        # 第二段：等待并接收 Entity3 返回的最终消息
        # =========================
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind((listen_ip, listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg3（不计时）
                data = conn.recv(2048)

                seg2_start = time.perf_counter()

                msg3 = Parse_Message(data)

                M_16 = msg3.get("M_16")

                M_17 = msg3.get("M_17")

                T3 = msg3.get("T3")

                M_14 = msg3.get("M_14")

                M_18 = Chebyshev_chaotic_map(SP_j,M_14)

                n_4 = Recover_Data(M_16,16,Hash(Concat_Data(HID_j,M_18,T3)))

                SK = Hash(Concat_Data(HID_j,HID_k,n2,n_4,T1,T3))

                print(f"SK computed by user is {SK}")

                M_177 = Hash(Concat_Data(SK,n2,n_4,M_18,T3))

                if M_177==M_17:

                    print("M_17 has been checked")

                else:

                    print("M_17 has not been checked")

                    os._exit(1)

                seg2_end = time.perf_counter()
                metrics["Entity1"] += _elapsed_ms(seg2_start, seg2_end)

        metrics["Entity1"] = round(metrics["Entity1"], 4)
        metrics["Entity1_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity1 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity2（Control Center）
# 消息流：
# 1) 接收 Entity1 的 r1
# 2) Entity2 -> Entity3 : r2
# =========================================
def CC_Entity(listen_port, uav_ip, uav_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg1（不计时）
                data = conn.recv(2048)

                # =========================
                # 收到 Msg1 后处理并发送 Msg2 给 Entity3
                # =========================
                seg_start = time.perf_counter()

                msg1 = Parse_Message(data)

                M_2 =msg1.get("M_2")

                M_4 = msg1.get("M_4")

                M_5 = msg1.get("M_5")

                M_6 = msg1.get("M_6")

                T1 = msg1.get("T1")

                s = Read_data("our_cs","s")

                ID_s = Read_data("our_cs","ID_s")

                M_7 = Hash(Concat_Data(ID_s,s))

                M_7_split = Split_Data(M_7,16,16)

                M_8 = Chebyshev_chaotic_map(Xor_Data(M_7_split[0],M_7_split[1]),M_2)

                HID_j_re = Xor_Data(M_4,M_8)

                HID_j = Read_data("our_cs","HID_j")

                if HID_j==HID_j_re:

                    print("HID_j has been found")

                else:
                    print("HID_j has been NOT found")

                    os._exit(1)

                ID_j = Read_data("our_cs","ID_j")

                D_j = Read_data("our_cs","D_J")

                E_j = Read_data("our_cs","E_j")

                Data = Xor_Data(D_j,Hash(Concat_Data(ID_j,s)))

                Data_split = Split_Data(Data,32,32)

                C_j = Data_split[0]

                HID_k = Data_split[1]

                E_jj = Hash(Concat_Data(C_j,HID_k,ID_j,HID_j,s))

                if E_jj==E_j:

                    print("E_jj has been checked")

                else:

                    print("E_jj has been NOT checked")

                    os._exit(1)

                Data2 = Xor_Data(M_5,Hash(Concat_Data(HID_j,M_8,T1)))

                Data2_split = Split_Data(Data2,32,16)

                HID_k_re = Data2_split[0]

                n_2 = Data2_split[1]

                M_66 = Hash(Concat_Data(ID_j,HID_j,HID_k_re,M_8,n_2,T1))

                if M_66==M_6:

                    print("M_66 has been checked")

                else:

                    print("M_66 has been NOT checked")

                    os._exit(1)

                A_k = Read_data("our_cs","A_k")

                M_9 = Chebyshev_chaotic_map(n_2,A_k)

                M_10 = Chebyshev_chaotic_map(n_2,HID_k)

                T2 = Generate_Timestamp()

                M_11 = Xor_Data(Concat_Data(HID_j,n_2,C_j),Hash(Concat_Data(HID_k,M_9,T2)))

                M_12 = Hash(Concat_Data(HID_j,HID_k,n_2,C_j,M_9,T2))

                msg2 = Create_message({
                    "M_10":M_10,
                    "M_11":M_11,
                    "M_12":M_12,
                    "T2":T2,
                    "T1":T1
                })

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as uav_sock:
                    uav_sock.connect((uav_ip, uav_port))
                    uav_sock.sendall(msg2)

                    print("Entity2: 已将消息发送给 Entity3。")

                seg_end = time.perf_counter()
                metrics["Entity2"] = _elapsed_ms(seg_start, seg_end)

        metrics["Entity2"] = round(metrics["Entity2"], 4)
        metrics["Entity2_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity2 protocol error: {e}"
        print(metrics["error"])


# =========================================
# Entity3（UAV）
# 消息流：
# 2) 接收 Entity2 的 r2
# 3) Entity3 -> Entity1 : r3
# =========================================
def UAV_Entity(listen_port, user_ip, user_port, metrics):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
            server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server_sock.bind(('0.0.0.0', listen_port))
            server_sock.listen(1)

            conn, addr = server_sock.accept()
            with conn:
                # 等待接收 Msg2（不计时）
                data = conn.recv(2048)

                # =========================
                # 收到 Msg2 后处理并发送 Msg3 给 Entity1
                # =========================
                seg_start = time.perf_counter()

                msg2 = Parse_Message(data)

                M_10 = msg2.get("M_10")

                M_11 = msg2.get("M_11")

                M_12 = msg2.get("M_12")

                T2 = msg2.get("T2")

                SP_k =Read_data("our_drone","SP_k")

                M_13 = Chebyshev_chaotic_map(SP_k,M_10)

                HID_k = Read_data("our_drone", "HID_k")

                Data = Xor_Data(M_11,Hash(Concat_Data(HID_k,M_13,T2)))

                Data_split = Split_Data(Data,32,16,32)

                HID_j = Data_split[0]

                n2 = Data_split[1]

                C_j = Data_split[2]

                M_122 = Hash(Concat_Data(HID_j,HID_k,n2,C_j,M_13,T2))

                if M_122==M_12:

                    print("M_122 has been checked")

                else:

                    print("M_122 has been NOT checked")

                    os._exit(1)

                n3 =Generate_Nonce()

                n4 = Generate_Nonce()

                M_14 = Chebyshev_chaotic_map(n3,HID_j)

                M_15 = Chebyshev_chaotic_map(n3,C_j)

                T3 = Generate_Timestamp()

                M_16 = Xor_Data(n4,Hash(Concat_Data(HID_j,M_15,T3)))

                T1 = msg2.get("T1")

                SK = Hash(Concat_Data(HID_j,HID_k,n2,n4,T1,T3))


                print(f"SK computed by drone is {SK}")

                M_17 =Hash(Concat_Data(SK,n2,n4,M_15,T3))

                msg3 = Create_message({
                    "M_14":M_14,
                    "M_16":M_16,
                    "M_17":M_17,
                    "T3":T3
                })

                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as user_sock:
                    user_sock.connect((user_ip, user_port))
                    user_sock.sendall(msg3)

                    print("Entity3: 已将最终消息发送给 Entity1。")

                seg_end = time.perf_counter()
                metrics["Entity3"] = _elapsed_ms(seg_start, seg_end)

        metrics["Entity3"] = round(metrics["Entity3"], 4)
        metrics["Entity3_success"] = True

    except Exception as e:
        metrics["error"] = f"Entity3 protocol error: {e}"
        print(metrics["error"])


# =========================================
# 主协议入口
# =========================================
def Proposed_Protocol():
    metrics = _init_metrics()

    entity1_listen_ip = "127.0.0.1"
    entity1_listen_port = 9501

    entity2_port = 9502
    entity3_port = 9503

    entity2_thread = threading.Thread(
        target=CC_Entity,
        args=(entity2_port, '127.0.0.1', entity3_port, metrics)
    )
    entity3_thread = threading.Thread(
        target=UAV_Entity,
        args=(entity3_port, entity1_listen_ip, entity1_listen_port, metrics)
    )
    entity1_thread = threading.Thread(
        target=User_Entity,
        args=('127.0.0.1', entity2_port, entity1_listen_ip, entity1_listen_port, metrics)
    )

    entity2_thread.start()
    time.sleep(0.25)

    entity3_thread.start()
    time.sleep(0.25)

    entity1_thread.start()

    entity2_thread.join()
    entity3_thread.join()
    entity1_thread.join()

    metrics["Entity1"] = round(metrics["Entity1"], 4)
    metrics["Entity2"] = round(metrics["Entity2"], 4)
    metrics["Entity3"] = round(metrics["Entity3"], 4)

    metrics["total_time"] = round(
        metrics["Entity1"] + metrics["Entity2"] + metrics["Entity3"],
        4
    )

    if (
        metrics["Entity1_success"]
        and metrics["Entity2_success"]
        and metrics["Entity3_success"]
        and metrics["error"] is None
    ):
        metrics["success"] = True

    return metrics


if __name__ == "__main__":
    result = Proposed_Protocol()
    print("\n===== Simple Protocol Timing Result =====")
    print(f"Entity1 Time : {result['Entity1']:.4f} ms")
    print(f"Entity2 Time : {result['Entity2']:.4f} ms")
    print(f"Entity3 Time : {result['Entity3']:.4f} ms")
    print(f"Total Time   : {result['total_time']:.4f} ms")
    print(f"Success      : {result['success']}")
    print(f"Error        : {result['error']}")